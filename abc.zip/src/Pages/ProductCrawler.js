const ProductCrawler = () => {
    return (
        <div className='m-3'>
            <h1>Product Crawler</h1>
        </div>  
    )
}

export default ProductCrawler